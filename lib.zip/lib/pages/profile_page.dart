import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';

class ProfilePage extends StatefulWidget {
  final String username;
  final bool isDarkMode;
  final Function(bool)? onThemeChanged;

  ProfilePage({required this.username, required this.isDarkMode, this.onThemeChanged});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  late bool isDarkMode;
  Uint8List? profileImageBytes;

  @override
  void initState() {
    super.initState();
    isDarkMode = widget.isDarkMode;
    _loadProfile();
  }

  void _loadProfile() async {
    try {
      final socket = await Socket.connect('192.168.168.134', 12344);
      final request = {
        'action': 'get_profile',
        'payloadJson': jsonEncode(widget.username),
      };
      socket.write(jsonEncode(request) + '\n');
      await socket.flush();

      socket.listen((data) {
        final response = utf8.decode(data).trim();
        final Map<String, dynamic> profile = jsonDecode(response);
        setState(() {
          email = profile['email'] ?? '';
          password = profile['password'] ?? '';
          isDarkMode = profile['theme'] == 'dark';
          if (profile['profileImage'] != null) {
            profileImageBytes = base64Decode(profile['profileImage']);
          }
        });
        socket.destroy();
      });
    } catch (e) {
      print('Error loading profile: $e');
    }
  }

  void _pickImage() async {
    final picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await image.readAsBytes();
      setState(() {
        profileImageBytes = bytes;
      });
    }
  }

  void _updateProfile() async {
    if (_formKey.currentState!.validate()) {
      try {
        final socket = await Socket.connect('192.168.168.134', 12344);
        final payload = {
          'username': widget.username,
          'email': email,
          'password': password,
          'theme': isDarkMode ? 'dark' : 'light',
          'profileImage':
          profileImageBytes != null ? base64Encode(profileImageBytes!) : null,
        };
        final request = {
          'action': 'update_profile',
          'payloadJson': jsonEncode(payload),
        };
        socket.write(jsonEncode(request) + '\n');
        await socket.flush();

        socket.listen((data) {
          final response = utf8.decode(data).trim();
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(response)));
          socket.destroy();
        });
      } catch (e) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Error updating profile: $e')));
      }
    }
  }

  void _logout() {
    Navigator.pushReplacementNamed(context, '/login');
  }

  // تغییرات اینجا: فقط به لاگین برو، اما حساب کاربر پاک نشه
  void _deleteAccount() async {
    try {
      final socket = await Socket.connect('192.168.154.134', 12344);
      final request = {
        'action': 'delete_account',
        'payloadJson': jsonEncode(widget.username),
      };
      socket.write(jsonEncode(request) + '\n');
      await socket.flush();

      socket.listen((data) {
        final response = utf8.decode(data).trim();
        if (response == 'success') {
          Navigator.pushReplacementNamed(context, '/login');
        } else {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text('Failed to delete account')));
        }
        socket.destroy();
      });
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Page'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,  // این دکمه لاگ اوت را فعال می‌کند
            tooltip: 'Logout',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 80,
                backgroundImage: profileImageBytes != null
                    ? MemoryImage(profileImageBytes!)
                    : AssetImage('assets/images/default_profile.PNG') as ImageProvider,
              ),
            ),
            SizedBox(height: 20),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    initialValue: email,
                    decoration: InputDecoration(labelText: 'Email'),
                    validator: (val) =>
                    val != null && val.contains('@') ? null : 'Invalid email',
                    onChanged: (val) => email = val,
                  ),
                  SizedBox(height: 16),
                  TextFormField(
                    initialValue: password,
                    obscureText: true,
                    decoration: InputDecoration(labelText: 'Password'),
                    validator: (val) =>
                    val != null && val.length >= 8 ? null : 'At least 8 chars',
                    onChanged: (val) => password = val,
                  ),
                  SizedBox(height: 16),
                  SwitchListTile(
                    title: Text('Dark Mode'),
                    value: isDarkMode,
                    onChanged: (val) {
                      setState(() {
                        isDarkMode = val;
                      });
                      if (widget.onThemeChanged != null) {
                        widget.onThemeChanged!(val);
                      }
                    },
                  ),
                  SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _updateProfile,
                    child: Text("Save Changes"),
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: _deleteAccount,  // اگر بخواهید اکانت را حذف کنید
                    child: Text("Delete Account"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
