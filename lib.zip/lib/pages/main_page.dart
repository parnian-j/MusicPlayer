import 'package:flutter/material.dart';
import 'home_page.dart';
import 'explore_page.dart';
import 'profile_page.dart';

class MainPage extends StatefulWidget {
  final String username;
  final bool isDarkMode;
  final Function(bool)? onThemeChanged;

  const MainPage({Key? key, required this.username, required this.isDarkMode, this.onThemeChanged}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;
  late bool _isDarkMode;

  @override
  void initState() {
    super.initState();
    _isDarkMode = widget.isDarkMode;
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      // صفحه خانه (HomePage)
      HomePage(
        socketUrl: 'ws://192.168.154.134:12345',
        username: widget.username,  // ارسال username به HomePage
      ),
      // صفحه اکسپلور (ExplorePage)
      ExplorePage(socketUrl: 'ws://192.168.154.134:12345'),
      // صفحه پروفایل (ProfilePage)
      ProfilePage(
        username: widget.username,  // ارسال username به ProfilePage
        isDarkMode: _isDarkMode,
        onThemeChanged: (val) {
          setState(() {
            _isDarkMode = val;
          });
          if (widget.onThemeChanged != null) widget.onThemeChanged!(val);
        },
      ),
    ];

    final Color _bgColor = _isDarkMode ? Colors.black : Colors.white;
    final Color _selectedColor = Colors.cyanAccent;
    final Color _unselectedColor = _isDarkMode ? Colors.white70 : Colors.black54;

    return Scaffold(
      backgroundColor: _bgColor,
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        backgroundColor: _bgColor,
        selectedItemColor: _selectedColor,
        unselectedItemColor: _unselectedColor,
        showUnselectedLabels: false,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.library_music),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: 'Explore',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}